<?php
if (!defined('ABSPATH')) { exit; }

class WTWP_Export {
    private static function dom($html) {
        if (!class_exists('DOMDocument')) { return false; }
        $old = libxml_use_internal_errors(true); $dom = new DOMDocument();
        $ok = $dom->loadHTML('<?xml encoding="utf-8" ?>'.$html, LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);
        libxml_clear_errors(); libxml_use_internal_errors($old); return $ok ? $dom : false;
    }
    public static function extract_title($html) {
        $dom = self::dom($html); if (!$dom) { return __('Website document','website-to-word-pdf'); }
        $n = $dom->getElementsByTagName('title');
        return $n->length ? sanitize_text_field($n->item(0)->textContent) : __('Website document','website-to-word-pdf');
    }
    private static function choose_content_root($dom, $xp) {
        $queries = array(
            '//main', '//article', '//*[@role="main"]',
            '//*[contains(concat(" ",normalize-space(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"))," ")," article ")]',
            '//*[contains(concat(" ",normalize-space(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"))," ")," entry-content ")]',
            '//*[contains(concat(" ",normalize-space(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"))," ")," post-content ")]',
            '//*[contains(concat(" ",normalize-space(translate(@id,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"))," ")," content ")]',
            '//*[contains(concat(" ",normalize-space(translate(@id,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"))," ")," article ")]'
        );
        $candidates = array();
        foreach ($queries as $q) {
            $nodes = $xp->query($q);
            if ($nodes) { foreach ($nodes as $node) { $candidates[spl_object_hash($node)] = $node; } }
        }
        if (!$candidates) {
            $nodes = $xp->query('//body//*[self::div or self::td or self::center or self::section or self::table]');
            if ($nodes) { foreach ($nodes as $node) { $candidates[spl_object_hash($node)] = $node; } }
        }
        $best = null; $best_score = 0;
        foreach ($candidates as $node) {
            $text = trim(preg_replace('/\s+/u', ' ', $node->textContent));
            $length = function_exists('mb_strlen') ? mb_strlen($text) : strlen($text);
            if ($length < 250) { continue; }
            $link_text = '';
            foreach ($node->getElementsByTagName('a') as $a) { $link_text .= ' ' . $a->textContent; }
            $link_length = function_exists('mb_strlen') ? mb_strlen($link_text) : strlen($link_text);
            $density = min(0.98, $link_length / max(1, $length));
            $attrs = strtolower($node->getAttribute('id') . ' ' . $node->getAttribute('class'));
            $bonus = preg_match('/article|content|entry|post|chapter|lecture|text|body|main/', $attrs) ? 1.35 : 1.0;
            $penalty = preg_match('/sidebar|menu|nav|footer|header|widget|comment|related|breadcrumb|social|share|cookie|advert/', $attrs) ? 0.08 : 1.0;
            $score = $length * (1 - $density) * $bonus * $penalty;
            if ($score > $best_score) { $best_score = $score; $best = $node; }
        }
        if ($best) { return $best; }
        return $dom->getElementsByTagName('body')->item(0) ?: $dom->documentElement;
    }

    public static function html_to_blocks($html, $base_url = '') {
        $dom = self::dom($html);
        if (!$dom) { $t=trim(wp_strip_all_tags($html)); return $t ? array(array('type'=>'p','text'=>$t)) : array(); }
        $xp = new DOMXPath($dom);
        $remove_queries = array(
            '//script','//style','//noscript','//svg','//canvas','//iframe','//form','//nav','//header','//footer','//aside',
            '//*[@hidden]','//*[@aria-hidden="true"]',
            '//*[contains(concat(" ",normalize-space(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"))," ")," cookie ")]',
            '//*[contains(concat(" ",normalize-space(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"))," ")," navigation ")]',
            '//*[contains(concat(" ",normalize-space(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"))," ")," navbar ")]',
            '//*[contains(concat(" ",normalize-space(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"))," ")," sidebar ")]',
            '//*[contains(concat(" ",normalize-space(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"))," ")," menu ")]',
            '//*[contains(concat(" ",normalize-space(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"))," ")," footer ")]',
            '//*[contains(concat(" ",normalize-space(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"))," ")," header ")]',
            '//*[contains(concat(" ",normalize-space(translate(@id,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"))," ")," menu ")]',
            '//*[contains(concat(" ",normalize-space(translate(@id,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"))," ")," sidebar ")]',
            '//*[contains(concat(" ",normalize-space(translate(@id,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"))," ")," navigation ")]'
        );
        foreach ($remove_queries as $q) {
            $nodes=$xp->query($q);
            if ($nodes) { $list=array(); foreach($nodes as $n){$list[]=$n;} foreach($list as $n){if($n->parentNode){$n->parentNode->removeChild($n);}} }
        }
        $root = self::choose_content_root($dom, $xp);
        $out=array(); self::walk($root,$out,$base_url);
        $normal_text = '';
        foreach ($out as $block) { if (!empty($block['text'])) { $normal_text .= ' ' . $block['text']; } }
        $legacy = self::legacy_text($root);
        $normal_len = function_exists('mb_strlen') ? mb_strlen(trim($normal_text)) : strlen(trim($normal_text));
        $legacy_len = function_exists('mb_strlen') ? mb_strlen(trim($legacy)) : strlen(trim($legacy));
        if ($normal_len < 250 || $legacy_len > ($normal_len * 1.35)) {
            if ($legacy_len > $normal_len) {
                $out = array();
                foreach (preg_split('/\n{2,}/', trim($legacy)) as $paragraph) {
                    $paragraph = trim(preg_replace('/[ \t]+/u', ' ', $paragraph));
                    if ($paragraph !== '' && (function_exists('mb_strlen') ? mb_strlen($paragraph) : strlen($paragraph)) >= 2) {
                        $out[] = array('type'=>'p', 'text'=>$paragraph);
                    }
                }
            }
        }
        $clean=array(); $seen=array();
        foreach($out as $b) {
            $b['text']=trim(preg_replace('/\s+/u',' ',html_entity_decode($b['text'],ENT_QUOTES|ENT_HTML5,'UTF-8')));
            if (in_array($b['type'],array('image','link'),true)) { if (!empty($b['url']) && filter_var($b['url'],FILTER_VALIDATE_URL)) {$clean[]=$b;} continue; }
            if ($b['type']==='table') { if (!empty($b['rows'])) {$clean[]=$b;} continue; }
            if ($b['text']==='' || (function_exists('mb_strlen') ? mb_strlen($b['text']) : strlen($b['text']))<2) {continue;}
            // Remove short menu-like labels and repeated navigation fragments.
            if (strlen($b['text']) < 90 && preg_match('/^(home page|home|contact|about|introduction|index|ordering page|guest book|health page|topics of importance|audio books|tracts page|truth links|charles finney page|asa mahan page)$/i', $b['text'])) { continue; }
            $k=md5($b['type'].'|'.$b['text']); if(isset($seen[$k]))continue; $seen[$k]=true; $clean[]=$b;
            if(count($clean)>=500)break;
        }
        return $clean;
    }

    private static function legacy_text($node) {
        if (!$node) return '';
        if ($node->nodeType === XML_TEXT_NODE || $node->nodeType === XML_CDATA_SECTION_NODE) {
            return preg_replace('/\s+/u', ' ', $node->nodeValue);
        }
        if ($node->nodeType !== XML_ELEMENT_NODE && $node->nodeType !== XML_DOCUMENT_NODE) return '';
        $tag = strtolower($node->nodeName);
        if (in_array($tag, array('script','style','noscript','svg','canvas','iframe','nav','header','footer','aside','form'), true)) return '';
        $block_tags = array('address','article','blockquote','br','dd','div','dl','dt','fieldset','figcaption','figure','h1','h2','h3','h4','h5','h6','hr','li','ol','p','pre','section','table','tr','td','th','ul');
        $result = in_array($tag, $block_tags, true) ? "\n\n" : '';
        foreach ($node->childNodes as $child) $result .= self::legacy_text($child);
        if (in_array($tag, $block_tags, true)) $result .= "\n\n";
        return $result;
    }

    public static function resolve_link($url,$base) { return self::absolute_url($url,$base); }
    private static function absolute_url($url,$base) {
        $url=trim($url); if(!$url)return '';
        if (preg_match('#^https?://#i',$url)) return esc_url_raw($url);
        if (!$base || strpos($url,'data:')===0 || strpos($url,'javascript:')===0) return '';
        $p=wp_parse_url($base); if(empty($p['scheme'])||empty($p['host']))return '';
        if (strpos($url,'//')===0) return esc_url_raw($p['scheme'].':'.$url);
        if (strpos($url,'/')===0) return esc_url_raw($p['scheme'].'://'.$p['host'].(isset($p['port'])?':'.$p['port']:'').$url);
        $path=isset($p['path'])?$p['path']:'/'; $dir=substr($path,0,strrpos($path,'/')+1);
        return esc_url_raw($p['scheme'].'://'.$p['host'].$dir.$url);
    }
    private static function walk($node,&$out,$base) {
        if(!$node || $node->nodeType!==XML_ELEMENT_NODE)return;
        $tag=strtolower($node->nodeName);
        if($tag==='img') {
            $src=$node->getAttribute('src'); if(!$src)$src=$node->getAttribute('data-src');
            $url=self::absolute_url($src,$base); $alt=sanitize_text_field($node->getAttribute('alt'));
            if($url)$out[]=array('type'=>'image','url'=>$url,'text'=>$alt?:__('Image','website-to-word-pdf'));
            return;
        }
        if($tag==='a') {
            $href=self::absolute_url($node->getAttribute('href'),$base);
            $txt=trim(preg_replace('/\\s+/u',' ',$node->textContent));
            if($txt!=='' && $href) $out[]=array('type'=>'link','url'=>$href,'text'=>$txt);
            else { foreach($node->childNodes as $child) if($child->nodeType===XML_ELEMENT_NODE) self::walk($child,$out,$base); }
            return;
        }
        if($tag==='table') {
            $rows=array();
            foreach($node->getElementsByTagName('tr') as $tr) {
                $cells=array(); foreach($tr->childNodes as $cell) {
                    if($cell->nodeType===XML_ELEMENT_NODE && in_array(strtolower($cell->nodeName),array('td','th'),true)) {
                        $cells[]=trim(preg_replace('/\s+/u',' ',$cell->textContent));
                    }
                }
                if($cells)$rows[]=$cells;
            }
            if($rows)$out[]=array('type'=>'table','rows'=>$rows,'text'=>'');
            return;
        }
        if(in_array($tag,array('h1','h2','h3','h4','h5','h6','p','li','blockquote','pre'),true)) {
            $t=trim($node->textContent); if($t!=='')$out[]=array('type'=>preg_match('/^h[1-6]$/',$tag)?$tag:($tag==='li'?'li':'p'),'text'=>$t);
            return;
        }
        foreach($node->childNodes as $child) if($child->nodeType===XML_ELEMENT_NODE) self::walk($child,$out,$base);
    }
    /** Modernise historical English while preserving the original block structure. */
    public static function modernise_blocks($blocks, $api_key, &$error = '') {
        $segments = array();
        foreach ($blocks as $bi => $block) {
            if (isset($block['text']) && $block['text'] !== '' && $block['type'] !== 'image') {
                $segments[] = array('id' => 'b' . $bi, 'path' => array($bi, 'text'), 'text' => $block['text']);
            }
            if (!empty($block['rows']) && is_array($block['rows'])) {
                foreach ($block['rows'] as $ri => $row) {
                    foreach ($row as $ci => $cell) {
                        if (is_string($cell) && trim($cell) !== '') {
                            $segments[] = array('id' => 'b' . $bi . 'r' . $ri . 'c' . $ci, 'path' => array($bi, 'rows', $ri, $ci), 'text' => $cell);
                        }
                    }
                }
            }
        }
        if (!$segments) { return $blocks; }

        // Small batches keep requests reliable on typical shared hosting.
        foreach (array_chunk($segments, 12) as $batch) {
            $payload = array();
            foreach ($batch as $segment) { $payload[] = array('id' => $segment['id'], 'text' => $segment['text']); }
            $body = array(
                'model' => 'gpt-4.1-mini',
                'temperature' => 0.2,
                'response_format' => array('type' => 'json_object'),
                'messages' => array(
                    array('role' => 'system', 'content' => 'You are a careful historical-English modernisation editor. Rewrite each supplied passage in clear contemporary English. Preserve every factual claim, argument, qualification, theological meaning, named entity, biblical quotation/reference, and paragraph-level intent. Do not summarise, omit, add commentary, or invent material. Retain specialist theological terms when replacing them could change meaning. Modernise obsolete spelling and archaic grammar only where the meaning is clear; if a phrase is ambiguous, keep it close to the original. Return valid JSON only in the form {"translations":[{"id":"same id","text":"modernised text"}]}. Include exactly one result for every input id.'),
                    array('role' => 'user', 'content' => wp_json_encode(array('passages' => $payload), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES))
                )
            );
            $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
                'timeout' => 90,
                'headers' => array('Authorization' => 'Bearer ' . $api_key, 'Content-Type' => 'application/json'),
                'body' => wp_json_encode($body),
                'limit_response_size' => 2097152
            ));
            if (is_wp_error($response)) { $error = __('Could not contact the modernisation service: ', 'website-to-word-pdf') . $response->get_error_message(); return $blocks; }
            $status = (int) wp_remote_retrieve_response_code($response);
            $raw = (string) wp_remote_retrieve_body($response);
            if ($status < 200 || $status >= 300) {
                $decoded_error = json_decode($raw, true);
                $detail = isset($decoded_error['error']['message']) ? sanitize_text_field($decoded_error['error']['message']) : sprintf(__('HTTP %d', 'website-to-word-pdf'), $status);
                $error = __('The modernisation service returned an error: ', 'website-to-word-pdf') . $detail;
                return $blocks;
            }
            $decoded = json_decode($raw, true);
            $content = isset($decoded['choices'][0]['message']['content']) ? $decoded['choices'][0]['message']['content'] : '';
            $result = json_decode($content, true);
            if (!is_array($result) || empty($result['translations']) || !is_array($result['translations'])) {
                $error = __('The modernisation service returned an unreadable response. No document was exported; please try again.', 'website-to-word-pdf');
                return $blocks;
            }
            $translated = array();
            foreach ($result['translations'] as $entry) {
                if (isset($entry['id'], $entry['text']) && is_string($entry['text'])) { $translated[$entry['id']] = $entry['text']; }
            }
            foreach ($batch as $segment) {
                if (!isset($translated[$segment['id']]) || trim($translated[$segment['id']]) === '') {
                    $error = __('The modernisation service did not return every passage. No document was exported to avoid silently losing text.', 'website-to-word-pdf');
                    return $blocks;
                }
                $path = $segment['path'];
                if (count($path) === 2) { $blocks[$path[0]][$path[1]] = $translated[$segment['id']]; }
                else { $blocks[$path[0]][$path[1]][$path[2]][$path[3]] = $translated[$segment['id']]; }
            }
        }
        return $blocks;
    }

    public static function prepare_media($blocks) {
        $count=0;
        foreach($blocks as &$b) {
            if($b['type']!=='image' || $count>=12) continue;
            $url=esc_url_raw($b['url']);
            if(!$url || !wp_http_validate_url($url)) continue;
            $r=wp_safe_remote_get($url,array('timeout'=>10,'redirection'=>2,'limit_response_size'=>2097152,
                'headers'=>array('User-Agent'=>'WordPress Website Document Converter/'.WTWP_VERSION)));
            if(is_wp_error($r) || wp_remote_retrieve_response_code($r)<200 || wp_remote_retrieve_response_code($r)>=300) continue;
            $mime=strtolower(trim(explode(';',(string)wp_remote_retrieve_header($r,'content-type'))[0]));
            $bytes=wp_remote_retrieve_body($r);
            if(!$bytes || strlen($bytes)>2097152) continue;
            $ext='';
            if($mime==='image/jpeg' || $mime==='image/jpg') $ext='jpg';
            elseif($mime==='image/png') $ext='png';
            elseif($mime==='image/gif') $ext='gif';
            elseif($mime==='image/webp') $ext='webp';
            if(!$ext) continue;
            $info=@getimagesizefromstring($bytes);
            if(!$info || empty($info[0]) || empty($info[1]) || $info[0]>3000 || $info[1]>3000) continue;
            $b['media']=array('bytes'=>$bytes,'mime'=>$mime,'ext'=>$ext,'width'=>$info[0],'height'=>$info[1]);
            $count++;
        }
        unset($b);
        return $blocks;
    }
    private static function x($s){return htmlspecialchars($s,ENT_XML1|ENT_COMPAT,'UTF-8');}
    public static function make_docx($title,$blocks) {
        if(!class_exists('ZipArchive'))return new WP_Error('wtwp_zip_missing',__('PHP ZipArchive is required for DOCX and batch exports.','website-to-word-pdf'));
        $tmp=wp_tempnam('wtwp.docx'); if(!$tmp)return new WP_Error('wtwp_tmp','Could not create temporary DOCX.');
        $z=new ZipArchive(); if($z->open($tmp,ZipArchive::OVERWRITE)!==true){@unlink($tmp);return new WP_Error('wtwp_zip','Could not create DOCX archive.');}
        $body='<w:p><w:pPr><w:pStyle w:val="Title"/></w:pPr><w:r><w:t>'.self::x($title).'</w:t></w:r></w:p>';
        $rels=''; $media=array(); $rid=1; $image_no=0;
        foreach($blocks as $b) {
            if($b['type']==='image') {
                if(!empty($b['media'])) {
                    $m=$b['media']; $name='image'.(++$image_no).'.'.$m['ext']; $z->addFromString('word/media/'.$name,$m['bytes']);
                    $relId='rId'.$rid++; $target='media/'.$name;
                    $relType='http://schemas.openxmlformats.org/officeDocument/2006/relationships/image';
                    $rels.='<Relationship Id="'.$relId.'" Type="'.$relType.'" Target="'.$target.'"/>';
                    $cx=round(min(5.8, max(1.0, $m['width']/120))*914400); $cy=round($cx*$m['height']/$m['width']);
                    $body.='<w:p><w:r><w:drawing><wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture" distT="0" distB="0" distL="0" distR="0"><wp:extent cx="'.$cx.'" cy="'.$cy.'"/><wp:docPr id="'.$image_no.'" name="'.self::x($name).'"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="'.$image_no.'" name="'.self::x($name).'"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="'.$relId.'" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="'.$cx.'" cy="'.$cy.'"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>';
                } else {
                    $body.='<w:p><w:r><w:t>'.self::x($b['text'].' — '.$b['url']).'</w:t></w:r></w:p>';
                }
                continue;
            }
            if($b['type']==='link') {
                $relId='rId'.$rid++;
                $rels.='<Relationship Id="'.$relId.'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="'.self::x($b['url']).'" TargetMode="External"/>';
                $body.='<w:p><w:hyperlink r:id="'.$relId.'" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><w:r><w:rPr><w:color w:val="0563C1"/><w:u w:val="single"/></w:rPr><w:t>'.self::x($b['text']).'</w:t></w:r></w:hyperlink></w:p>';
                continue;
            }
            if($b['type']==='table') {
                $body.='<w:tbl><w:tblPr><w:tblW w:w="0" w:type="auto"/><w:tblBorders><w:top w:val="single" w:sz="6" w:color="A6A6A6"/><w:left w:val="single" w:sz="6" w:color="A6A6A6"/><w:bottom w:val="single" w:sz="6" w:color="A6A6A6"/><w:right w:val="single" w:sz="6" w:color="A6A6A6"/><w:insideH w:val="single" w:sz="4" w:color="D9D9D9"/><w:insideV w:val="single" w:sz="4" w:color="D9D9D9"/></w:tblBorders></w:tblPr>';
                foreach($b['rows'] as $ri=>$row){$body.='<w:tr>';foreach($row as $cell){$body.='<w:tc><w:tcPr><w:tcW w:w="2400" w:type="dxa"/>'.($ri===0?'<w:shd w:fill="EAF1F8"/>':'').'</w:tcPr><w:p><w:r><w:rPr>'.($ri===0?'<w:b/>':'').'</w:rPr><w:t>'.self::x($cell).'</w:t></w:r></w:p></w:tc>';}$body.='</w:tr>';}$body.='</w:tbl>';continue;
            }
            $style=preg_match('/^h[1-6]$/',$b['type'])?'Heading'.substr($b['type'],1):'Normal';
            $text=($b['type']==='li'?'• ':'').$b['text'];
            $body.='<w:p><w:pPr><w:pStyle w:val="'.$style.'"/></w:pPr><w:r><w:t xml:space="preserve">'.self::x($text).'</w:t></w:r></w:p>';
        }
        $document='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'.$body.'<w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="900" w:right="900" w:bottom="900" w:left="900"/></w:sectPr></w:body></w:document>';
        $styles='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="22"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:pPr><w:spacing w:after="240"/></w:pPr><w:rPr><w:b/><w:color w:val="17365D"/><w:sz w:val="36"/></w:rPr></w:style>';
        for($i=1;$i<=6;$i++)$styles.='<w:style w:type="paragraph" w:styleId="Heading'.$i.'"><w:name w:val="heading '.$i.'"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="180" w:after="80"/></w:pPr><w:rPr><w:b/><w:color w:val="1F4E79"/><w:sz w:val="'.(32-$i*2).'"/></w:rPr></w:style>';
        $styles.='</w:styles>';
        $ct='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="jpg" ContentType="image/jpeg"/><Default Extension="jpeg" ContentType="image/jpeg"/><Default Extension="png" ContentType="image/png"/><Default Extension="gif" ContentType="image/gif"/><Default Extension="webp" ContentType="image/webp"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>';
        $rootrels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>';
        $z->addFromString('[Content_Types].xml',$ct);$z->addFromString('_rels/.rels',$rootrels);$z->addFromString('word/document.xml',$document);$z->addFromString('word/styles.xml',$styles);
        $z->addFromString('word/_rels/document.xml.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'.$rels.'</Relationships>');
        $z->close();$data=file_get_contents($tmp);@unlink($tmp);return $data;
    }
    private static function pdf_text($s) {
        $s=html_entity_decode($s,ENT_QUOTES|ENT_HTML5,'UTF-8');
        if(function_exists('iconv')){$v=@iconv('UTF-8','Windows-1252//TRANSLIT//IGNORE',$s);if($v!==false)$s=$v;}else{$s=preg_replace('/[^\x20-\x7E]/','?',$s);}
        return str_replace(array('\\','(',')',"\r"),array('\\\\','\\(','\\)',''),$s);
    }
    public static function make_pdf($title,$blocks) {
        $lines=array(array('text'=>self::pdf_text($title),'size'=>18,'gap'=>15));
        foreach($blocks as $b) {
            if($b['type']==='image'){$t='Image: '.$b['text'].' | '.$b['url'];$b['type']='p';$b['text']=$t;}
            if($b['type']==='link'){$b['text']=$b['text'].' ('.$b['url'].')';$b['type']='p';}
            if($b['type']==='table') {
                foreach($b['rows'] as $ri=>$row){$prefix=$ri===0?'TABLE: ':'  ';$t=$prefix.implode('  |  ',array_map('strip_tags',$row));$lines[]=array('text'=>self::pdf_text($t),'size'=>$ri===0?9:8,'gap'=>3);}continue;
            }
            $heading=preg_match('/^h[1-6]$/',$b['type']);$size=$heading?13:10;$max=$heading?76:100;
            $words=preg_split('/\s+/',self::pdf_text($b['text']));$line='';
            foreach($words as $word){if($line!=='' && strlen($line.' '.$word)>$max){$lines[]=array('text'=>$line,'size'=>$size,'gap'=>2);$line=$word;}else{$line.=($line===''?'':' ').$word;}}
            if($line!=='')$lines[]=array('text'=>($b['type']==='li'?'• ':'').$line,'size'=>$size,'gap'=>$heading?8:4);
        }
        $chunks=array_chunk($lines,48);if(!$chunks)$chunks=array(array());
        $obj=array();$obj[1]='<< /Type /Catalog /Pages 2 0 R >>';$kids=array();
        foreach($chunks as $i=>$chunk){$pid=4+$i*2;$cid=$pid+1;$kids[]=$pid.' 0 R';$stream="BT\n50 790 Td\n";
            foreach($chunk as $ln){$stream.='/F1 '.$ln['size']." Tf\n(".$ln['text'].") Tj\n0 -".($ln['size']+$ln['gap'])." Td\n";}$stream.="ET\n";
            $obj[$pid]='<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents '.$cid.' 0 R >>';
            $obj[$cid]='<< /Length '.strlen($stream)." >>\nstream\n".$stream."endstream";
        }
        $obj[2]='<< /Type /Pages /Kids ['.implode(' ',$kids).'] /Count '.count($kids).' >>';$obj[3]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';ksort($obj);
        $pdf="%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";$offs=array(0);foreach($obj as $id=>$o){$offs[$id]=strlen($pdf);$pdf.=$id." 0 obj\n".$o."\nendobj\n";}
        $xref=strlen($pdf);$n=max(array_keys($obj))+1;$pdf.="xref\n0 ".$n."\n0000000000 65535 f \n";
        for($i=1;$i<$n;$i++)$pdf.=isset($offs[$i])?sprintf("%010d 00000 n \n",$offs[$i]):"0000000000 00000 f \n";
        return $pdf."trailer\n<< /Size ".$n." /Root 1 0 R >>\nstartxref\n".$xref."\n%%EOF";
    }
}
