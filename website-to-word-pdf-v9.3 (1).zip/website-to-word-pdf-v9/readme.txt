=== Website to Word & PDF Converter ===
Contributors: word-life
Tags: website, html, word, pdf, book catalogue
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 9.3.0

Extract readable webpage content and export Word/PDF documents. Includes a book metadata catalogue with resumable, short-request website scanning.

= Catalogue scanning in 9.3.0 =
- Scans same-domain links in batches of two pages per AJAX request.
- Uses a short 7-second request timeout and does not invoke the remote-browser fallback during catalogue scans.
- Saves scan state for up to one hour and displays page/book progress.
- Stops at 100 pages per scan to protect shared hosting.
- Provides editable book metadata before CSV/XLSX export.
- CAPTCHA, login, paywall and inaccessible pages cannot be scanned.

= Notes =
The scanner follows discoverable internal links from the starting page. It does not guarantee every website page will be found; pages not linked from the start page or its descendants may require a separate starting URL.
