<?php
/**
 * Plugin Name: Website to Word & PDF Converter
 * Description: Extract readable webpage content and export DOCX/PDF, with optional AI modernisation of historical English.
 * Version: 9.3.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Word-Life
 * License: GPL-2.0-or-later
 * Text Domain: website-to-word-pdf
 */
if (!defined('ABSPATH')) { exit; }

define('WTWP_VERSION', '9.3.0');
define('WTWP_DIR', plugin_dir_path(__FILE__));
require_once WTWP_DIR . 'includes/class-wtwp-export.php';

final class WTWP_Plugin {
    public function __construct() {
        add_action('admin_menu', array($this, 'menu'));
        add_action('admin_post_wtwp_export', array($this, 'export'));
        add_action('admin_post_wtwp_preview_catalogue', array($this, 'preview_catalogue'));
        add_action('wp_ajax_wtwp_catalogue_batch', array($this, 'ajax_catalogue_batch'));
        add_action('admin_post_wtwp_catalogue_review', array($this, 'show_catalogue_review'));
        add_action('admin_post_wtwp_export_catalogue_reviewed', array($this, 'export_reviewed_catalogue'));
        add_action('admin_post_wtwp_save_settings', array($this, 'save_settings'));
        add_shortcode('website_document_converter', array($this, 'shortcode'));
    }

    public function menu() {
        add_management_page(__('Website to Word/PDF', 'website-to-word-pdf'), __('Website to Word/PDF', 'website-to-word-pdf'),
            'manage_options', 'wtwp-converter', array($this, 'admin_page'));
    }

    public function admin_page() {
        if (!current_user_can('manage_options')) { return; }
        $this->render_form(true);
    }

    public function shortcode($atts = array()) {
        if (!is_user_logged_in() || !current_user_can('edit_posts')) {
            return '<p>' . esc_html__('Please log in with editing permissions to use the document converter.', 'website-to-word-pdf') . '</p>';
        }
        ob_start();
        echo '<div class="wtwp-shortcode">';
        $this->render_form(false);
        echo '</div>';
        return ob_get_clean();
    }

    private function render_form($admin) {
        $posts = get_posts(array('post_type' => array('post', 'page'), 'post_status' => 'publish',
            'numberposts' => 200, 'orderby' => 'title', 'order' => 'ASC'));
        ?>
        <div class="wrap">
            <?php if ($admin) : ?>
                <?php if (!empty($_GET['wtwp_settings_saved'])) : ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e('Renderer settings saved.', 'website-to-word-pdf'); ?></p></div><?php endif; ?>
                <h1><?php esc_html_e('Website to Word & PDF Converter', 'website-to-word-pdf'); ?></h1>
                <div class="notice notice-info inline"><p><?php esc_html_e('The converter improves article-area selection and removes common navigation/sidebar elements before export. It first tries the normal website request. If the site returns a verification page or too little article text, it can retry using a remote browser renderer. Configure the renderer token below. The remote service receives the URL you submit.', 'website-to-word-pdf'); ?></p></div>
                <h2><?php esc_html_e('Remote browser renderer (optional)', 'website-to-word-pdf'); ?></h2>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="wtwp_save_settings">
                    <?php wp_nonce_field('wtwp_save_settings_action', 'wtwp_settings_nonce'); ?>
                    <table class="form-table" role="presentation"><tr><th scope="row"><label for="wtwp_browserless_token"><?php esc_html_e('Browserless API token', 'website-to-word-pdf'); ?></label></th><td>
                    <input type="password" autocomplete="new-password" class="regular-text" name="wtwp_browserless_token" id="wtwp_browserless_token" value="" placeholder="<?php echo esc_attr(get_option('wtwp_browserless_token') ? __('Token saved — leave blank to keep it', 'website-to-word-pdf') : __('Paste your API token here', 'website-to-word-pdf')); ?>">
                    <p class="description"><?php esc_html_e('Create an account with Browserless and paste its API token here. The token is stored in your WordPress options and is never displayed again. Tick the box to remove it. Do not send the token to anyone.', 'website-to-word-pdf'); ?></p>
                    <label><input type="checkbox" name="wtwp_clear_browserless_token" value="1"> <?php esc_html_e('Remove saved token', 'website-to-word-pdf'); ?></label>
                    </td></tr></table>
                    <h2><?php esc_html_e('Modern English conversion (optional)', 'website-to-word-pdf'); ?></h2>
                    <table class="form-table" role="presentation"><tr><th scope="row"><label for="wtwp_openai_api_key"><?php esc_html_e('OpenAI API key', 'website-to-word-pdf'); ?></label></th><td>
                    <input type="password" autocomplete="new-password" class="regular-text" name="wtwp_openai_api_key" id="wtwp_openai_api_key" value="" placeholder="<?php echo esc_attr(get_option('wtwp_openai_api_key') ? __('API key saved — leave blank to keep it', 'website-to-word-pdf') : __('Paste your OpenAI API key here', 'website-to-word-pdf')); ?>">
                    <p class="description"><?php esc_html_e('Required only when modernisation is selected. The key is stored privately in WordPress options and is never displayed again. OpenAI API usage is billed separately by OpenAI.', 'website-to-word-pdf'); ?></p>
                    <label><input type="checkbox" name="wtwp_clear_openai_api_key" value="1"> <?php esc_html_e('Remove saved OpenAI API key', 'website-to-word-pdf'); ?></label>
                    </td></tr></table>
                    <?php submit_button(__('Save settings', 'website-to-word-pdf')); ?>
                </form>
            <?php endif; ?>
            <p><?php esc_html_e('Convert public HTML pages or your published WordPress content. The converter extracts the main article area where possible, removes common navigation and sidebar elements, and retries blocked or JavaScript-heavy pages through an optional remote browser renderer and refuses to export verification pages as documents.', 'website-to-word-pdf'); ?></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="wtwp_export">
                <?php wp_nonce_field('wtwp_export_action', 'wtwp_nonce'); ?>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><label for="wtwp_source"><?php esc_html_e('Content source', 'website-to-word-pdf'); ?></label></th>
                        <td><select name="wtwp_source" id="wtwp_source">
                            <option value="url"><?php esc_html_e('Public website URL(s)', 'website-to-word-pdf'); ?></option>
                            <option value="wp"><?php esc_html_e('My WordPress pages/posts', 'website-to-word-pdf'); ?></option>
                        </select></td></tr>
                    <tr id="wtwp-url-row"><th scope="row"><label for="wtwp_urls"><?php esc_html_e('Website URL(s)', 'website-to-word-pdf'); ?></label></th>
                        <td><textarea name="wtwp_urls" id="wtwp_urls" rows="5" class="large-text" placeholder="https://example.com/article&#10;https://example.com/another-article"></textarea>
                        <p class="description"><?php esc_html_e('Enter one public URL per line. Up to 10 starting URLs per batch.', 'website-to-word-pdf'); ?></p>
                        <label><input type="checkbox" name="wtwp_follow_links" value="1" checked> <?php esc_html_e('Also include linked chapter/article pages from the same website (combine as one document)', 'website-to-word-pdf'); ?></label>
                        <p class="description"><?php esc_html_e('Follows up to 20 same-domain links one level deep; this is a limit, not a guarantee that every chapter on a large site will be found. It skips obvious navigation, files and external links. Turn this off to export only the URL entered.', 'website-to-word-pdf'); ?></p></td></tr>
                    <tr id="wtwp-post-row" style="display:none"><th scope="row"><label for="wtwp_posts"><?php esc_html_e('Published pages/posts', 'website-to-word-pdf'); ?></label></th>
                        <td><select name="wtwp_posts[]" id="wtwp_posts" multiple size="8" class="large-text">
                            <?php foreach ($posts as $post) : ?>
                                <option value="<?php echo esc_attr($post->ID); ?>"><?php echo esc_html(get_the_title($post) . ' (' . $post->post_type . ')'); ?></option>
                            <?php endforeach; ?>
                        </select><p class="description"><?php esc_html_e('Use Ctrl (Windows) or Command (Mac) to select multiple items. Up to 10 per batch.', 'website-to-word-pdf'); ?></p></td></tr>
                    <tr><th scope="row"><?php esc_html_e('Export format', 'website-to-word-pdf'); ?></th>
                        <td><label><input type="radio" name="wtwp_format" value="docx" checked> Microsoft Word (.docx)</label><br>
                        <label><input type="radio" name="wtwp_format" value="pdf"> PDF (.pdf)</label><br>
                        <label><input type="radio" name="wtwp_format" value="both"> Both (DOCX + PDF)</label></td></tr>
                    <tr><th scope="row"><?php esc_html_e('Language', 'website-to-word-pdf'); ?></th><td>
                        <label><input type="checkbox" name="wtwp_modernise" value="1" checked> <?php esc_html_e('Modernise historical / old-fashioned English (recommended)', 'website-to-word-pdf'); ?></label>
                        <p class="description"><?php esc_html_e('Uses AI to rewrite the extracted text in clear present-day English while preserving the original meaning, theological terms, biblical references, headings and paragraph order. Uncheck to keep the source wording unchanged. Images and links are not translated.', 'website-to-word-pdf'); ?></p>
                    </td></tr>
                    <tr><th scope="row"><label for="wtwp_title"><?php esc_html_e('Document title (single export only)', 'website-to-word-pdf'); ?></label></th>
                        <td><input type="text" class="regular-text" name="wtwp_title" id="wtwp_title" maxlength="160" /></td></tr>
                </table>
                <?php submit_button(__('Convert and download', 'website-to-word-pdf')); ?>
            </form>
            <p class="description"><?php esc_html_e('Supported images are embedded in Word and PDF where the server has the required image support. Hyperlinks are preserved. Tables and headings receive improved styling. Only convert content you own or have permission to reproduce. No login/paywall bypass is performed.', 'website-to-word-pdf'); ?></p>
        </div>
            <hr>
            <h2><?php esc_html_e('Book information catalogue', 'website-to-word-pdf'); ?></h2>
            <p><?php esc_html_e('Scan a whole public website or an author/index page and build one catalogue row per detected book or publication. Includes title, author, ISBN, category, description, cover image, publication year, publisher and source URL.', 'website-to-word-pdf'); ?></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="wtwp_preview_catalogue">
                <?php wp_nonce_field('wtwp_catalogue_action', 'wtwp_catalogue_nonce'); ?>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><label for="wtwp_catalogue_urls"><?php esc_html_e('Website or starting page URL(s)', 'website-to-word-pdf'); ?></label></th>
                    <td><textarea name="wtwp_catalogue_urls" id="wtwp_catalogue_urls" rows="5" class="large-text" placeholder="https://example.com/ or https://example.com/author/"></textarea>
                    <p class="description"><?php esc_html_e('Enter one or more website homepages, author pages, book indexes or individual book pages. The scanner checks sitemap files and follows same-domain links to discover book listings. It scans up to 100 pages per starting website, processed in small batches to protect your hosting account; pages blocked by CAPTCHA/login cannot be read.', 'website-to-word-pdf'); ?></p></td></tr>
                    <tr><th scope="row"><?php esc_html_e('Catalogue format', 'website-to-word-pdf'); ?></th><td>
                    <label><input type="radio" name="wtwp_catalogue_format" value="xlsx" checked> Excel workbook (.xlsx)</label><br>
                    <label><input type="radio" name="wtwp_catalogue_format" value="csv"> CSV (.csv, Excel-compatible)</label></td></tr>
                </table>
                <?php submit_button(__('Extract details and review before export', 'website-to-word-pdf')); ?>
            </form>
        </div>
        <script>
        (function(){
            var s=document.getElementById('wtwp_source'),u=document.getElementById('wtwp-url-row'),p=document.getElementById('wtwp-post-row');
            if(!s||!u||!p)return;
            function toggle(){var wp=s.value==='wp';u.style.display=wp?'none':'';p.style.display=wp?'':'none';}
            s.addEventListener('change',toggle);toggle();
        })();
        </script>
        <?php
    }

    public function save_settings() {
        if (!current_user_can('manage_options')) { wp_die(esc_html__('You are not allowed to change these settings.', 'website-to-word-pdf'), 403); }
        check_admin_referer('wtwp_save_settings_action', 'wtwp_settings_nonce');
        if (!empty($_POST['wtwp_clear_browserless_token'])) {
            delete_option('wtwp_browserless_token');
        } elseif (isset($_POST['wtwp_browserless_token']) && trim((string) wp_unslash($_POST['wtwp_browserless_token'])) !== '') {
            $token = sanitize_text_field(wp_unslash($_POST['wtwp_browserless_token']));
            update_option('wtwp_browserless_token', $token, false);
        }
        if (!empty($_POST['wtwp_clear_openai_api_key'])) {
            delete_option('wtwp_openai_api_key');
        } elseif (isset($_POST['wtwp_openai_api_key']) && trim((string) wp_unslash($_POST['wtwp_openai_api_key'])) !== '') {
            $api_key = sanitize_text_field(wp_unslash($_POST['wtwp_openai_api_key']));
            update_option('wtwp_openai_api_key', $api_key, false);
        }
        wp_safe_redirect(add_query_arg(array('page'=>'wtwp-converter','wtwp_settings_saved'=>'1'), admin_url('tools.php')));
        exit;
    }

    private function browserless_render($url, &$error = '') {
        $token = trim((string) get_option('wtwp_browserless_token', ''));
        if ($token === '') { $error = __('Remote browser retry is not configured. Add a Browserless API token in the converter settings.', 'website-to-word-pdf'); return ''; }
        // Fixed provider endpoint; only the submitted public URL is sent in the JSON body.
        $endpoint = 'https://production-ams.browserless.io/content?token=' . rawurlencode($token);
        $response = wp_remote_post($endpoint, array(
            'timeout' => 90,
            'redirection' => 0,
            'headers' => array('Content-Type'=>'application/json','Cache-Control'=>'no-cache'),
            'body' => wp_json_encode(array('url'=>$url)),
            'limit_response_size' => 5242880,
        ));
        if (is_wp_error($response)) { $error = __('Remote browser request failed: ', 'website-to-word-pdf') . $response->get_error_message(); return ''; }
        $status = (int) wp_remote_retrieve_response_code($response);
        $html = (string) wp_remote_retrieve_body($response);
        if ($status < 200 || $status >= 300) { $error = sprintf(__('Remote browser returned HTTP %d. Check the API token and account limits.', 'website-to-word-pdf'), $status); return ''; }
        if ($html === '') { $error = __('Remote browser returned an empty page.', 'website-to-word-pdf'); return ''; }
        if (strlen($html) > 5242880) { $error = __('Rendered page exceeded the 5 MB safety limit.', 'website-to-word-pdf'); return ''; }
        return $html;
    }

    private function looks_like_challenge($html) {
        $sample = strtolower(substr(wp_strip_all_tags($html), 0, 12000));
        $needles = array('one moment, please', 'checking your browser', 'verify you are human', 'verify that you are human', 'attention required', 'cloudflare ray id', 'enable javascript and cookies to continue', 'please wait while your request is being verified');
        foreach ($needles as $needle) { if (strpos($sample, $needle) !== false) { return true; } }
        return false;
    }


    private function fetch_html($url, &$error = '') {
        $response = wp_safe_remote_get($url, array('timeout'=>25, 'redirection'=>5, 'limit_response_size'=>5242880,
            'headers'=>array('User-Agent'=>'Mozilla/5.0 (compatible; WebsiteDocumentConverter/'.WTWP_VERSION.'; +'.home_url('/').')','Accept'=>'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')));
        $html = '';
        if (is_wp_error($response)) { $error = $response->get_error_message(); }
        else {
            $status = (int) wp_remote_retrieve_response_code($response);
            $type = (string) wp_remote_retrieve_header($response, 'content-type');
            if ($status < 200 || $status >= 300) { $error = 'HTTP ' . $status; }
            elseif (stripos($type, 'text/html') === false && stripos($type, 'application/xhtml+xml') === false) { $error = 'Non-HTML response'; }
            else { $html = (string) wp_remote_retrieve_body($response); }
        }
        $blocks = $html ? WTWP_Export::html_to_blocks($html, $url) : array();
        $length = 0;
        foreach ($blocks as $block) { if (!empty($block['text'])) { $length += strlen($block['text']); } }
        if (!$html || $this->looks_like_challenge($html) || $length < 350 || !$blocks) {
            $browser_error = '';
            $rendered = $this->browserless_render($url, $browser_error);
            if ($rendered !== '' && !$this->looks_like_challenge($rendered)) {
                $rendered_blocks = WTWP_Export::html_to_blocks($rendered, $url);
                $rendered_length = 0;
                foreach ($rendered_blocks as $block) { if (!empty($block['text'])) { $rendered_length += strlen($block['text']); } }
                if ($rendered_length > $length) { $html = $rendered; $blocks = $rendered_blocks; $length = $rendered_length; }
            } elseif ($browser_error !== '') { $error = trim($error . '; ' . $browser_error, '; '); }
        }
        return array($html, $blocks, $length);
    }

    private function linked_article_urls($html, $base_url) {
        if (!class_exists('DOMDocument') || !$html) { return array(); }
        $base = wp_parse_url($base_url);
        if (empty($base['host'])) { return array(); }
        $host = strtolower($base['host']);
        $dom = new DOMDocument();
        $previous = libxml_use_internal_errors(true);
        $dom->loadHTML('<?xml encoding="utf-8" ?>' . $html);
        libxml_clear_errors(); libxml_use_internal_errors($previous);
        $out = array(); $seen = array($this->canonical_url($base_url)=>true);
        $skip = array('home','about','contact','privacy','terms','login','register','search','next','previous','previous page','next page');
        foreach ($dom->getElementsByTagName('a') as $a) {
            $href = trim($a->getAttribute('href'));
            $label = strtolower(trim(preg_replace('/\s+/u', ' ', $a->textContent)));
            if ($href === '' || $label === '' || strlen($label) > 180) { continue; }
            if (preg_match('#^(mailto:|tel:|javascript:|\\#)#i', $href)) { continue; }
            $url = WTWP_Export::resolve_link($href, $base_url);
            if (!$url || !wp_http_validate_url($url)) { continue; }
            $p = wp_parse_url($url);
            if (empty($p['host']) || strtolower($p['host']) !== $host) { continue; }
            if (isset($p['query']) || isset($p['fragment'])) { continue; }
            if (preg_match('/\.(pdf|docx?|xlsx?|pptx?|zip|jpg|jpeg|png|gif|webp|mp3|mp4|css|js|xml)$/i', $p['path'] ?? '')) { continue; }
            if (in_array($label, $skip, true) || preg_match('/^(home|about|contact|privacy|terms|login|menu|search)\b/i', $label)) { continue; }
            $canonical = $this->canonical_url($url);
            if (!isset($seen[$canonical])) { $seen[$canonical] = true; $out[] = array('url'=>$url, 'label'=>sanitize_text_field($a->textContent)); }
            if (count($out) >= 20) { break; }
        }
        return $out;
    }

    private function canonical_url($url) {
        $p = wp_parse_url($url);
        if (empty($p['host'])) { return $url; }
        $scheme = isset($p['scheme']) ? strtolower($p['scheme']) : 'https';
        $path = isset($p['path']) && $p['path'] !== '' ? $p['path'] : '/';
        return $scheme . '://' . strtolower($p['host']) . $path;
    }

    private function get_sources(&$errors = array()) {
        $source = isset($_POST['wtwp_source']) ? sanitize_key(wp_unslash($_POST['wtwp_source'])) : 'url';
        $items = array();
        if ($source === 'wp') {
            $ids = isset($_POST['wtwp_posts']) ? array_slice(array_map('absint', (array) wp_unslash($_POST['wtwp_posts'])), 0, 10) : array();
            foreach ($ids as $id) {
                $post = get_post($id);
                if ($post && in_array($post->post_type, array('post','page'), true) && $post->post_status === 'publish' && current_user_can('read_post', $id)) {
                    $items[] = array('title' => get_the_title($post), 'blocks' => WTWP_Export::html_to_blocks(apply_filters('the_content', $post->post_content)));
                }
            }
        } elseif ($source === 'url') {
            $raw = isset($_POST['wtwp_urls']) ? sanitize_textarea_field(wp_unslash($_POST['wtwp_urls'])) : '';
            $urls = array_slice(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $raw))), 0, 10);
            foreach ($urls as $url) {
                $url = esc_url_raw($url);
                if (!$url || !wp_http_validate_url($url)) { continue; }
                $parts = wp_parse_url($url);
                if (empty($parts['scheme']) || !in_array(strtolower($parts['scheme']), array('http','https'), true) || empty($parts['host'])) { continue; }
                $fetch_error = '';
                list($html, $blocks, $text_length) = $this->fetch_html($url, $fetch_error);
                if ($html && !$this->looks_like_challenge($html) && $blocks && $text_length >= 250) {
                    $title = WTWP_Export::extract_title($html);
                    $combined = $blocks;
                    $follow = !empty($_POST['wtwp_follow_links']);
                    if ($follow) {
                        $linked = $this->linked_article_urls($html, $url);
                        $included = 0;
                        foreach ($linked as $link) {
                            $child_error = '';
                            list($child_html, $child_blocks, $child_length) = $this->fetch_html($link['url'], $child_error);
                            if (!$child_html || $this->looks_like_challenge($child_html) || !$child_blocks || $child_length < 250) { continue; }
                            $child_title = WTWP_Export::extract_title($child_html);
                            $combined[] = array('type'=>'h1', 'text'=>$child_title ?: $link['label']);
                            foreach ($child_blocks as $child_block) { $combined[] = $child_block; }
                            $included++;
                        }
                        if ($included > 0) {
                            $title .= ' — Complete collection';
                        }
                    }
                    $items[] = array('title'=>$title, 'blocks'=>$combined);
                } else {
                    $reason = $this->looks_like_challenge($html) ? __('The website returned an anti-bot verification page, not the article.', 'website-to-word-pdf') : __('The page did not contain enough extractable article text (minimum 250 characters).', 'website-to-word-pdf');
                    if ($fetch_error !== '') { $reason .= ' ' . $fetch_error; }
                    $errors[] = $url . ' — ' . $reason . ' ' . __('If the remote browser is also blocked, open the page normally and use the browser Save Page feature; this plugin does not solve CAPTCHAs or bypass access controls.', 'website-to-word-pdf');
                }
            }
        }
        return $items;
    }


    /** Extract book metadata from common Open Graph, Dublin Core, citation and Schema.org markup. */
    private function extract_book_metadata($html, $url) {
        $data = array('Book title'=>'','Author'=>'','ISBN'=>'','Category'=>'','Short Description'=>'','Cover image'=>'','Year of publication'=>'','Publisher'=>'');
        if (!class_exists('DOMDocument')) { return $data; }
        $old = libxml_use_internal_errors(true);
        $dom = new DOMDocument();
        $dom->loadHTML('<?xml encoding="utf-8" ?>' . $html, LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);
        libxml_clear_errors(); libxml_use_internal_errors($old);
        $xp = new DOMXPath($dom);
        $meta = array();
        foreach ($xp->query('//meta[@name or @property]') as $m) {
            $key = strtolower(trim($m->getAttribute('name') ?: $m->getAttribute('property')));
            $val = trim($m->getAttribute('content'));
            if ($key !== '' && $val !== '' && !isset($meta[$key])) { $meta[$key] = $val; }
        }
        $pick = function($keys) use ($meta) {
            foreach ($keys as $key) { $key = strtolower($key); if (!empty($meta[$key])) return $meta[$key]; }
            return '';
        };
        $data['Book title'] = $pick(array('og:title','twitter:title','citation_title','dc.title','dcterms.title'));
        $data['Author'] = $pick(array('author','citation_author','dc.creator','dcterms.creator','book.author'));
        $data['ISBN'] = $pick(array('book:isbn','isbn','citation_isbn','dc.identifier'));
        $data['Category'] = $pick(array('article:section','book:genre','category','section','dc.subject','dcterms.subject'));
        $data['Short Description'] = $pick(array('og:description','description','twitter:description','dc.description','dcterms.description'));
        $data['Cover image'] = $pick(array('og:image','twitter:image','twitter:image:src','image','citation_cover'));
        $data['Publisher'] = $pick(array('publisher','citation_publisher','dc.publisher','dcterms.publisher','book.publisher'));
        $date = $pick(array('article:published_time','datepublished','date','citation_publication_date','dc.date','dcterms.issued','publication_date'));
        if ($date && preg_match('/(18|19|20|21)\d{2}/', $date, $m)) { $data['Year of publication'] = $m[0]; }

        $jsonld = $xp->query('//script[@type="application/ld+json"]');
        $walk = function($node) use (&$walk, &$data) {
            if (!is_array($node)) return;
            if (isset($node['@graph']) && is_array($node['@graph'])) foreach ($node['@graph'] as $v) $walk($v);
            $types = isset($node['@type']) ? (array)$node['@type'] : array();
            $normal_types = array_map(function($type) { $type = strtolower((string)$type); $type = preg_replace('/^.*[\/#]/', '', $type); return $type; }, $types);
            if (array_intersect($normal_types, array('book','product','creativework'))) {
                if ($data['Book title']==='' && !empty($node['name'])) $data['Book title'] = is_string($node['name']) ? $node['name'] : '';
                if ($data['Author']==='' && !empty($node['author'])) {
                    $a=$node['author']; if (is_array($a)) $data['Author']=isset($a['name'])?$a['name']:(isset($a[0]['name'])?$a[0]['name']:'');
                    elseif (is_string($a)) $data['Author']=$a;
                }
                if ($data['ISBN']==='' && !empty($node['isbn'])) $data['ISBN']=$node['isbn'];
                if ($data['Publisher']==='' && !empty($node['publisher'])) {
                    $p=$node['publisher']; $data['Publisher']=is_array($p)?(isset($p['name'])?$p['name']:''):$p;
                }
                if ($data['Short Description']==='' && !empty($node['description'])) $data['Short Description']=$node['description'];
                if ($data['Cover image']==='' && !empty($node['image'])) {
                    $im=$node['image']; $data['Cover image']=is_array($im)?(isset($im['url'])?$im['url']:(isset($im[0])?$im[0]:'')):$im;
                }
                if ($data['Year of publication']==='' && !empty($node['datePublished']) && preg_match('/(18|19|20|21)\d{2}/',$node['datePublished'],$m)) $data['Year of publication']=$m[0];
                if ($data['Category']==='' && !empty($node['genre'])) $data['Category']=is_array($node['genre'])?implode(', ',$node['genre']):$node['genre'];
            }
            foreach ($node as $v) if (is_array($v)) $walk($v);
        };
        foreach ($jsonld as $script) {
            $obj=json_decode($script->textContent,true);
            if (is_array($obj)) $walk($obj);
        }
        if ($data['Book title']==='') {
            $title=$xp->query('//h1[1]'); if ($title && $title->length) $data['Book title']=trim($title->item(0)->textContent);
            if ($data['Book title']==='') { $t=$dom->getElementsByTagName('title'); if($t->length)$data['Book title']=trim($t->item(0)->textContent); }
        }
        if ($data['ISBN']==='' && preg_match('/\\b(?:ISBN(?:-1[03])?:?\\s*)?((?:97[89][\\s-]?)?\\d[\\d\\s-]{8,16}[\\dX])\\b/i', wp_strip_all_tags($html), $m)) $data['ISBN']=trim($m[1]);
        if ($data['Year of publication']==='' && $date && preg_match('/(18|19|20|21)\\d{2}/',$date,$m)) $data['Year of publication']=$m[0];
        if ($data['Cover image']!=='' && !preg_match('#^https?://#i',$data['Cover image'])) $data['Cover image']=WTWP_Export::resolve_link($data['Cover image'],$url);
        foreach ($data as $k=>$v) $data[$k]=sanitize_text_field(wp_strip_all_tags((string)$v));
        if (strlen($data['Short Description'])>1000) $data['Short Description']=substr($data['Short Description'],0,997).'...';
        return $data;
    }

    /** Discover same-site pages from sitemaps and internal links. Bounded to protect shared hosting. */
    private function discover_catalogue_pages($start_url, &$scan_notes = array()) {
        $parts = wp_parse_url($start_url);
        if (empty($parts['host'])) return array();
        $host = strtolower($parts['host']);
        $queue = array($start_url);
        $seen = array();
        $pages = array();
        $add_url = function($url) use (&$queue, &$seen, $host) {
            $url = esc_url_raw($url);
            if (!$url || !wp_http_validate_url($url)) return;
            $p = wp_parse_url($url);
            if (empty($p['host']) || strtolower($p['host']) !== $host) return;
            if (!empty($p['query']) || !empty($p['fragment'])) return;
            if (preg_match('/\.(pdf|docx?|xlsx?|pptx?|zip|jpg|jpeg|png|gif|webp|mp3|mp4|css|js)$/i', isset($p['path'])?$p['path']:'')) return;
            $key = $this->canonical_url($url);
            if (!isset($seen[$key]) && count($seen) < 150) { $seen[$key]=true; $queue[]=$url; }
        };
        // Discover sitemap locations advertised by robots.txt and common sitemap paths.
        $robots = wp_safe_remote_get(trailingslashit($parts['scheme'].'://'.$parts['host']).'robots.txt', array('timeout'=>10,'redirection'=>3,'limit_response_size'=>524288));
        if (!is_wp_error($robots) && wp_remote_retrieve_response_code($robots) < 400) {
            $body = (string) wp_remote_retrieve_body($robots);
            if (preg_match_all('/^\s*Sitemap:\s*(https?:\/\/\S+)/im', $body, $sm)) foreach ($sm[1] as $sitemap) $this->collect_sitemap_urls($sitemap, $host, $add_url, 2);
        }
        foreach (array('/sitemap.xml','/sitemap_index.xml','/wp-sitemap.xml') as $path) $this->collect_sitemap_urls($parts['scheme'].'://'.$parts['host'].$path, $host, $add_url, 2);
        $queue = array_values(array_unique($queue));
        while ($queue && count($pages) < 150) {
            $url = array_shift($queue);
            $key = $this->canonical_url($url);
            if (isset($pages[$key])) continue;
            $err = '';
            list($html, $blocks, $length) = $this->fetch_html($url, $err);
            if (!$html || $this->looks_like_challenge($html)) {
                $scan_notes[] = $url . ' — ' . ($err !== '' ? $err : 'page unavailable or anti-bot verification');
                continue;
            }
            $pages[$key] = array('url'=>$url, 'html'=>$html, 'length'=>$length);
            if (class_exists('DOMDocument')) {
                $dom = new DOMDocument(); $prev = libxml_use_internal_errors(true);
                $dom->loadHTML('<?xml encoding="utf-8" ?>'.$html);
                libxml_clear_errors(); libxml_use_internal_errors($prev);
                foreach ($dom->getElementsByTagName('a') as $a) {
                    $href = trim($a->getAttribute('href'));
                    if ($href === '' || preg_match('#^(mailto:|tel:|javascript:|#)#i', $href)) continue;
                    $add_url(WTWP_Export::resolve_link($href, $url));
                }
            }
        }
        if ($queue) $scan_notes[] = 'Scan limit reached: up to 150 pages were queued; increase the limit only if your hosting account can handle a larger crawl.';
        return $pages;
    }

    /** Add sitemap URLs recursively (including sitemap indexes), within the site's host. */
    private function collect_sitemap_urls($sitemap, $host, $add_url, $depth) {
        if ($depth < 0) return;
        $response = wp_safe_remote_get($sitemap, array('timeout'=>10,'redirection'=>3,'limit_response_size'=>2097152));
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) >= 400) return;
        $xml = (string) wp_remote_retrieve_body($response);
        if ($xml === '') return;
        if (preg_match_all('/<loc>\s*(.*?)\s*<\/loc>/is', $xml, $matches)) {
            foreach (array_slice($matches[1], 0, 500) as $loc) {
                $loc = html_entity_decode(trim(strip_tags($loc)), ENT_QUOTES, 'UTF-8');
                $p = wp_parse_url($loc);
                if (empty($p['host']) || strtolower($p['host']) !== $host) continue;
                if ($depth > 0 && preg_match('/\.xml(?:\.gz)?$/i', $loc)) $this->collect_sitemap_urls($loc, $host, $add_url, $depth-1);
                else $add_url($loc);
            }
        }
    }

    /** Decide whether a page represents a book/publication rather than a generic site page. */
    private function catalogue_page_is_book($html, $url, $row, $length) {
        $text = strtolower(wp_strip_all_tags($html));
        $path = strtolower((string) wp_parse_url($url, PHP_URL_PATH));
        $title = strtolower(isset($row['Book title']) ? $row['Book title'] : '');
        $has_identifier = !empty($row['ISBN']);
        $has_book_schema = preg_match('/"@type"\s*:\s*"(?:https?:\/\/schema\.org\/)?(?:book|creativework)"/i', $html);
        $book_terms = array('isbn','publisher','publication','published by','table of contents','contents','chapter 1','chapter i','preface','foreword','by charles','by rev.','by the author','book');
        $term_hits = 0;
        foreach ($book_terms as $term) if (strpos($text, $term) !== false || strpos($title, $term) !== false) $term_hits++;
        $path_hint = preg_match('/(book|works|memoir|theolog|lecture|revival|sermon|biograph|power-from|sanctif|finney)/i', $path);
        $link_count = 0;
        if (class_exists('DOMDocument')) { $d = new DOMDocument(); $prev = libxml_use_internal_errors(true); $d->loadHTML('<?xml encoding="utf-8" ?>'.$html); libxml_clear_errors(); libxml_use_internal_errors($prev); $link_count = $d->getElementsByTagName('a')->length; }
        if ($link_count > 35 && !$has_identifier && !$has_book_schema) return false; // likely an index/navigation page, not a single book
        return $has_identifier || $has_book_schema || ($length >= 700 && ($path_hint || $term_hits >= 2));
    }

    /** Start a resumable catalogue scan. Work is deliberately split across AJAX requests. */
    public function preview_catalogue() {
        if (!is_user_logged_in() || !current_user_can('edit_posts')) wp_die(esc_html__('You do not have permission to extract book information.', 'website-to-word-pdf'), 403);
        check_admin_referer('wtwp_catalogue_action', 'wtwp_catalogue_nonce');
        $raw = isset($_POST['wtwp_catalogue_urls']) ? sanitize_textarea_field(wp_unslash($_POST['wtwp_catalogue_urls'])) : '';
        $urls = array_slice(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $raw))), 0, 10);
        if (!$urls) wp_die(esc_html__('Enter at least one website, author, index or book page URL.', 'website-to-word-pdf'), 400);
        $seed = esc_url_raw($urls[0]);
        if (!$seed || !wp_http_validate_url($seed)) wp_die(esc_html__('The starting URL is not valid.', 'website-to-word-pdf'), 400);
        $parts = wp_parse_url($seed);
        if (empty($parts['host']) || empty($parts['scheme']) || !in_array(strtolower($parts['scheme']), array('http','https'), true)) wp_die(esc_html__('Use a full http or https website URL.', 'website-to-word-pdf'), 400);
        $token = wp_generate_password(24, false, false);
        $state = array('host'=>strtolower($parts['host']), 'queue'=>array($seed), 'seen'=>array(), 'rows'=>array(), 'notes'=>array(), 'count'=>0, 'format'=>(isset($_POST['wtwp_catalogue_format']) && sanitize_key(wp_unslash($_POST['wtwp_catalogue_format']))==='csv'?'csv':'xlsx'), 'started'=>time());
        set_transient('wtwp_cat_'.$token, $state, HOUR_IN_SECONDS);
        $nonce = wp_create_nonce('wtwp_cat_batch_'.$token);
        ?><!doctype html><html><head><meta charset="<?php echo esc_attr(get_bloginfo('charset')); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?php esc_html_e('Scanning website catalogue', 'website-to-word-pdf'); ?></title><?php wp_admin_css('common'); wp_admin_css('forms'); ?></head><body class="wp-admin"><div class="wrap" style="max-width:850px;margin:35px auto;padding:0 20px"><h1><?php esc_html_e('Scanning website for books', 'website-to-word-pdf'); ?></h1><p><?php esc_html_e('The scan is split into short requests to reduce timeout errors. Keep this browser tab open until it finishes.', 'website-to-word-pdf'); ?></p><div style="background:#ddd;height:16px;border-radius:8px;overflow:hidden"><div id="wtwp-progress" style="height:16px;width:2%;background:#2271b1"></div></div><p id="wtwp-status"><?php esc_html_e('Starting scan…', 'website-to-word-pdf'); ?></p><p id="wtwp-detail"></p><p id="wtwp-error" style="color:#b32d2e"></p><script>
(function(){const ajax=<?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>, token=<?php echo wp_json_encode($token); ?>, nonce=<?php echo wp_json_encode($nonce); ?>; let stopped=false;
async function run(){if(stopped)return;const body=new URLSearchParams({action:'wtwp_catalogue_batch',token:token,_ajax_nonce:nonce});try{const r=await fetch(ajax,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body.toString()});const j=await r.json();if(!j.success)throw new Error(j.data&&j.data.message?j.data.message:'The server could not continue the scan.');const d=j.data;document.getElementById('wtwp-status').textContent=d.status;document.getElementById('wtwp-detail').textContent=d.detail;document.getElementById('wtwp-progress').style.width=Math.min(98,Math.max(3,d.progress))+'%';if(d.done){document.getElementById('wtwp-progress').style.width='100%';document.getElementById('wtwp-status').textContent='Scan complete. Opening review…';window.location.href=d.review_url;return;}setTimeout(run,350);}catch(e){document.getElementById('wtwp-error').textContent=e.message+' You can retry by returning to the converter and starting a new scan.';stopped=true;}}
run();})();</script><p><a href="<?php echo esc_url(admin_url('tools.php?page=wtwp-converter')); ?>">&larr; <?php esc_html_e('Back to converter', 'website-to-word-pdf'); ?></a></p></div></body></html><?php
        exit;
    }

    /** Process at most two catalogue URLs per AJAX request; never invoke Browserless here. */
    public function ajax_catalogue_batch() {
        if (!is_user_logged_in() || !current_user_can('edit_posts')) wp_send_json_error(array('message'=>'Permission denied.'), 403);
        $token = isset($_POST['token']) ? sanitize_text_field(wp_unslash($_POST['token'])) : '';
        if (!$token || !wp_verify_nonce(isset($_POST['_ajax_nonce'])?sanitize_text_field(wp_unslash($_POST['_ajax_nonce'])):'', 'wtwp_cat_batch_'.$token)) wp_send_json_error(array('message'=>'Security check failed. Please start a new scan.'), 403);
        $key='wtwp_cat_'.$token; $state=get_transient($key);
        if (!is_array($state)) wp_send_json_error(array('message'=>'The scan session expired. Please start a new scan.'), 410);
        $done_count=0;
        while (!empty($state['queue']) && $done_count < 2 && (int)$state['count'] < 100) {
            $url=array_shift($state['queue']); $canon=$this->canonical_url($url);
            if (isset($state['seen'][$canon])) continue;
            $state['seen'][$canon]=true; $done_count++; $state['count']++;
            $error=''; $html=$this->catalogue_fetch_fast($url,$error);
            if (!$html || $this->looks_like_challenge($html)) { $state['notes'][]=$url.' — '.($error?:'blocked, empty or anti-bot verification page'); continue; }
            $row=$this->extract_book_metadata($html,$url); $plain=wp_strip_all_tags($html); $length=strlen($plain);
            if ($this->catalogue_page_is_book($html,$url,$row,$length) && ($row['Book title']!=='' || $row['Author']!=='' || $row['ISBN']!=='')) {
                $row['Source URL']=$url; $state['rows'][]=$row;
            }
            if (class_exists('DOMDocument')) {
                $dom=new DOMDocument(); $prev=libxml_use_internal_errors(true); $dom->loadHTML('<?xml encoding="utf-8" ?>'.$html, LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING); libxml_clear_errors(); libxml_use_internal_errors($prev);
                foreach ($dom->getElementsByTagName('a') as $a) {
                    $href=trim($a->getAttribute('href')); if ($href==='' || preg_match('#^(mailto:|tel:|javascript:|#)#i',$href)) continue;
                    $next=WTWP_Export::resolve_link($href,$url); $p=wp_parse_url($next);
                    if (empty($p['host']) || strtolower($p['host'])!==$state['host'] || !empty($p['query']) || !empty($p['fragment'])) continue;
                    if (preg_match('/\.(pdf|docx?|xlsx?|pptx?|zip|jpg|jpeg|png|gif|webp|mp3|mp4|css|js|xml)$/i',isset($p['path'])?$p['path']:'')) continue;
                    $label=strtolower(trim(preg_replace('/\s+/u',' ',$a->textContent)));
                    if ($label==='' || preg_match('/^(home|about|contact|privacy|terms|login|register|search|next|previous|top|menu)$/',$label)) continue;
                    $k=$this->canonical_url($next);
                    if (!isset($state['seen'][$k]) && count($state['queue'])<300 && !in_array($k,array_map(array($this,'canonical_url'),$state['queue']),true)) $state['queue'][]=$next;
                }
            }
        }
        if ((int)$state['count']>=100 && !empty($state['queue'])) $state['notes'][]='Safety limit reached at 100 pages. Start another scan from a different section to cover more of the website.';
        $finished=empty($state['queue']) || (int)$state['count']>=100;
        set_transient($key,$state,HOUR_IN_SECONDS);
        $progress=$finished?100:min(95,5+(int)(90*$state['count']/100));
        $detail=sprintf('Pages checked: %d · Books found: %d · Pages remaining in queue: %d',(int)$state['count'],count($state['rows']),count($state['queue']));
        $payload=array('done'=>$finished,'progress'=>$progress,'status'=>$finished?'Website scan finished.':'Scanning website links…','detail'=>$detail);
        if ($finished) $payload['review_url']=add_query_arg(array('action'=>'wtwp_catalogue_review','token'=>$token,'_wpnonce'=>wp_create_nonce('wtwp_cat_review_'.$token)),admin_url('admin-post.php'));
        wp_send_json_success($payload);
    }

    /** A short-timeout fetch dedicated to catalogue discovery; deliberately no remote-browser fallback. */
    private function catalogue_fetch_fast($url,&$error='') {
        $response=wp_safe_remote_get($url,array('timeout'=>7,'redirection'=>3,'limit_response_size'=>2097152,'headers'=>array('User-Agent'=>'Mozilla/5.0 (compatible; WebsiteCatalogue/'.WTWP_VERSION.'; +'.home_url('/').')','Accept'=>'text/html,application/xhtml+xml')));
        if (is_wp_error($response)) { $error=$response->get_error_message(); return ''; }
        $code=(int)wp_remote_retrieve_response_code($response); $type=(string)wp_remote_retrieve_header($response,'content-type');
        if ($code<200 || $code>=300) { $error='HTTP '.$code; return ''; }
        if (stripos($type,'text/html')===false && stripos($type,'application/xhtml+xml')===false) { $error='Not an HTML page'; return ''; }
        $html=(string)wp_remote_retrieve_body($response); if (strlen($html)>2097152) { $error='Page exceeded 2 MB limit'; return ''; }
        return $html;
    }

    /** Display the saved editable catalogue after all batches finish. */
    public function show_catalogue_review() {
        if (!is_user_logged_in() || !current_user_can('edit_posts')) wp_die(esc_html__('Permission denied.', 'website-to-word-pdf'),403);
        $token=isset($_GET['token'])?sanitize_text_field(wp_unslash($_GET['token'])):'';
        if (!$token || !wp_verify_nonce(isset($_GET['_wpnonce'])?sanitize_text_field(wp_unslash($_GET['_wpnonce'])):'','wtwp_cat_review_'.$token)) wp_die(esc_html__('Invalid review link.', 'website-to-word-pdf'),403);
        $state=get_transient('wtwp_cat_'.$token); if (!is_array($state)) wp_die(esc_html__('The saved scan expired. Please run it again.', 'website-to-word-pdf'),410);
        $rows=$state['rows']; $format=$state['format']; $scan_notes=$state['notes'];
        if (!$rows) { $msg='No book records were identified. '.implode(' | ',array_slice($scan_notes,0,10)); wp_die(esc_html($msg),esc_html__('Book extraction finished', 'website-to-word-pdf'),array('response'=>400)); }
        $fields=array('Book title','Author','ISBN','Category','Short Description','Cover image','Year of publication','Publisher','Source URL');
        ?><!doctype html><html><head><meta charset="<?php echo esc_attr(get_bloginfo('charset')); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?php esc_html_e('Review book catalogue', 'website-to-word-pdf'); ?></title><?php wp_admin_css('common'); wp_admin_css('forms'); ?></head><body class="wp-admin"><div class="wrap" style="max-width:1100px;margin:30px auto;padding:0 20px"><h1><?php esc_html_e('Review extracted book information', 'website-to-word-pdf'); ?></h1><p><?php printf(esc_html__('Checked %d pages and found %d possible book/publication records. Please review them before exporting.', 'website-to-word-pdf'),(int)$state['count'],count($rows)); ?></p>
        <?php if ($scan_notes) : ?><details style="margin:12px 0"><summary><?php printf(esc_html__('Scan notes (%d)', 'website-to-word-pdf'),count($scan_notes)); ?></summary><ul><?php foreach(array_slice($scan_notes,0,40) as $note): ?><li><?php echo esc_html($note); ?></li><?php endforeach; ?></ul></details><?php endif; ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="wtwp_export_catalogue_reviewed"><?php wp_nonce_field('wtwp_reviewed_catalogue_action','wtwp_reviewed_catalogue_nonce'); ?><input type="hidden" name="wtwp_catalogue_format" value="<?php echo esc_attr($format); ?>">
        <?php foreach($rows as $i=>$row): ?><fieldset style="border:1px solid #c3c4c7;background:#fff;padding:16px;margin:18px 0"><legend style="font-weight:600;padding:0 8px"><?php printf(esc_html__('Book %d','website-to-word-pdf'),$i+1); ?></legend><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px">
        <?php foreach($fields as $field): $value=isset($row[$field])?$row[$field]:''; $name='books['.$i.']['.$field.']'; ?><label style="display:block;font-weight:600"><?php echo esc_html($field); ?><?php if($field==='Short Description'): ?><textarea name="<?php echo esc_attr($name); ?>" rows="4" style="display:block;width:100%;margin-top:5px;font-weight:400"><?php echo esc_textarea($value); ?></textarea><?php else: ?><input type="text" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($value); ?>" style="display:block;width:100%;margin-top:5px;font-weight:400" <?php echo $field==='Source URL'?'readonly':''; ?>><?php endif; ?></label><?php endforeach; ?></div></fieldset><?php endforeach; ?>
        <?php submit_button(__('Download reviewed catalogue','website-to-word-pdf'),'primary','submit',true); ?></form><p><a href="<?php echo esc_url(admin_url('tools.php?page=wtwp-converter')); ?>">&larr; <?php esc_html_e('Back to converter','website-to-word-pdf'); ?></a></p></div></body></html><?php exit;
    }

    /** Validate reviewed values and export them as CSV or XLSX. */
    public function export_reviewed_catalogue() {
        if (!is_user_logged_in() || !current_user_can('edit_posts')) wp_die(esc_html__('You do not have permission to export book information.', 'website-to-word-pdf'), 403);
        check_admin_referer('wtwp_reviewed_catalogue_action', 'wtwp_reviewed_catalogue_nonce');
        $input = isset($_POST['books']) ? wp_unslash($_POST['books']) : array();
        if (!is_array($input) || !$input) wp_die(esc_html__('No reviewed book records were submitted.', 'website-to-word-pdf'), 400);
        $fields = array('Book title','Author','ISBN','Category','Short Description','Cover image','Year of publication','Publisher','Source URL');
        $rows = array();
        foreach (array_slice($input, 0, 100, true) as $record) {
            if (!is_array($record)) continue;
            $row = array();
            foreach ($fields as $field) {
                $value = isset($record[$field]) && is_scalar($record[$field]) ? trim((string)$record[$field]) : '';
                if ($field === 'Cover image' || $field === 'Source URL') $value = $value !== '' ? esc_url_raw($value) : '';
                else $value = sanitize_textarea_field($value);
                if ($field === 'Year of publication' && $value !== '' && !preg_match('/^(1[0-9]{3}|20[0-9]{2}|21[0-9]{2})$/', $value)) $value = '';
                $row[$field] = $value;
            }
            if ($row['Book title'] !== '' || $row['Author'] !== '' || $row['ISBN'] !== '') $rows[] = $row;
        }
        if (!$rows) wp_die(esc_html__('The reviewed records contain no book title, author or ISBN.', 'website-to-word-pdf'), 400);
        $format = isset($_POST['wtwp_catalogue_format']) ? sanitize_key(wp_unslash($_POST['wtwp_catalogue_format'])) : 'xlsx';
        $this->download_catalogue($rows, $format);
    }

    /** Create the requested spreadsheet from already validated rows. */
    private function download_catalogue($rows, $format) {
        $headers = array('Book title','Author','ISBN','Category','Short Description','Cover image','Year of publication','Publisher','Source URL');
        if ($format === 'csv') {
            $fp = fopen('php://temp', 'r+'); fputcsv($fp, $headers);
            foreach ($rows as $row) fputcsv($fp, array_map(function($h) use ($row) { return isset($row[$h]) ? $row[$h] : ''; }, $headers));
            rewind($fp); $csv = "\xEF\xBB\xBF" . stream_get_contents($fp); fclose($fp);
            $this->send_file($csv, 'book-catalogue.csv', 'text/csv; charset=utf-8');
        }
        if (!class_exists('ZipArchive')) wp_die(esc_html__('PHP ZipArchive is required to create an Excel workbook. Choose CSV if it is unavailable.', 'website-to-word-pdf'), 500);
        $tmp = wp_tempnam('wtwp-catalogue.xlsx'); $zip = new ZipArchive();
        if (!$tmp || $zip->open($tmp, ZipArchive::OVERWRITE) !== true) wp_die(esc_html__('Could not create Excel workbook.', 'website-to-word-pdf'), 500);
        $xmlEscape = function($s) { return htmlspecialchars((string)$s, ENT_XML1|ENT_QUOTES, 'UTF-8'); };
        $sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';
        $all = array($headers); foreach ($rows as $row) { $line = array(); foreach ($headers as $h) $line[] = isset($row[$h]) ? $row[$h] : ''; $all[] = $line; }
        foreach ($all as $ri => $line) { $r = $ri + 1; $sheet .= '<row r="'.$r.'">'; foreach ($line as $ci => $value) { $col=''; $n=$ci+1; while($n){$rem=($n-1)%26;$col=chr(65+$rem).$col;$n=(int)(($n-1)/26);} $sheet .= '<c r="'.$col.$r.'" t="inlineStr"><is><t xml:space="preserve">'.$xmlEscape($value).'</t></is></c>'; } $sheet .= '</row>'; }
        $sheet .= '</sheetData></worksheet>';
        $zip->addFromString('[Content_Types].xml','<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>');
        $zip->addFromString('_rels/.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
        $zip->addFromString('xl/workbook.xml','<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Book Catalogue" sheetId="1" r:id="rId1"/></sheets></workbook>');
        $zip->addFromString('xl/_rels/workbook.xml.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>');
        $zip->addFromString('xl/worksheets/sheet1.xml', $sheet); $zip->close();
        $data = file_get_contents($tmp); @unlink($tmp);
        $this->send_file($data, 'book-catalogue.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    }

    public function export() {
        if (!is_user_logged_in() || !current_user_can('edit_posts')) { wp_die(esc_html__('You do not have permission to export content.', 'website-to-word-pdf'), 403); }
        check_admin_referer('wtwp_export_action', 'wtwp_nonce');
        $errors = array();
        $items = $this->get_sources($errors);
        if (!$items) {
            $message = __('No readable article content could be retrieved.', 'website-to-word-pdf');
            if ($errors) { $message .= '<br><br>' . implode('<br>', array_map('esc_html', $errors)); }
            $message .= '<br><br>' . esc_html__('Check the URL, server access and whether the page requires JavaScript. This converter does not bypass logins or paywalls.', 'website-to-word-pdf');
            wp_die($message, esc_html__('Website conversion failed', 'website-to-word-pdf'), array('response'=>400));
        }
        if (!empty($_POST['wtwp_modernise'])) {
            $api_key = trim((string) get_option('wtwp_openai_api_key', ''));
            if ($api_key === '') {
                wp_die(esc_html__('Modern English conversion is selected, but no OpenAI API key is saved. Add your key under Tools → Website to Word/PDF → Modern English conversion, or uncheck the modernisation option and try again.', 'website-to-word-pdf'), esc_html__('API key required', 'website-to-word-pdf'), array('response'=>400));
            }
            foreach ($items as &$item) {
                $modernise_error = '';
                $item['blocks'] = WTWP_Export::modernise_blocks($item['blocks'], $api_key, $modernise_error);
                if ($modernise_error !== '') { unset($item); wp_die(esc_html($modernise_error), esc_html__('Modernisation failed', 'website-to-word-pdf'), array('response'=>502)); }
            }
            unset($item);
        }
        foreach ($items as &$item) { $item['blocks'] = WTWP_Export::prepare_media($item['blocks']); } unset($item);
        $format = isset($_POST['wtwp_format']) ? sanitize_key(wp_unslash($_POST['wtwp_format'])) : 'docx';
        $title_override = isset($_POST['wtwp_title']) ? sanitize_text_field(wp_unslash($_POST['wtwp_title'])) : '';
        if (count($items) === 1) {
            if ($title_override) { $items[0]['title'] = $title_override; }
            $ext = $format === 'pdf' ? 'pdf' : 'docx';
            if ($format === 'both') {
                $docx = WTWP_Export::make_docx($items[0]['title'], $items[0]['blocks']);
                if (is_wp_error($docx)) { wp_die(esc_html($docx->get_error_message()), 500); }
                $files = array(
                    sanitize_file_name($items[0]['title']) . '.docx' => $docx,
                    sanitize_file_name($items[0]['title']) . '.pdf' => WTWP_Export::make_pdf($items[0]['title'], $items[0]['blocks'])
                );
                $this->send_zip($files, 'website-documents.zip');
            }
            $data = $ext === 'pdf' ? WTWP_Export::make_pdf($items[0]['title'], $items[0]['blocks']) : WTWP_Export::make_docx($items[0]['title'], $items[0]['blocks']);
            if (is_wp_error($data)) { wp_die(esc_html($data->get_error_message()), 500); }
            $this->send_file($data, sanitize_file_name(remove_accents($items[0]['title'])) . '.' . $ext,
                $ext === 'pdf' ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
        }
        $files = array();
        foreach ($items as $i => $item) {
            $safe = sanitize_file_name(remove_accents($item['title']));
            if (!$safe) { $safe = 'document-' . ($i+1); }
            if ($format === 'pdf' || $format === 'both') { $files[$safe . '.pdf'] = WTWP_Export::make_pdf($item['title'], $item['blocks']); }
            if ($format === 'docx' || $format === 'both') {
                $docx = WTWP_Export::make_docx($item['title'], $item['blocks']);
                if (is_wp_error($docx)) { wp_die(esc_html($docx->get_error_message()), 500); }
                $files[$safe . '.docx'] = $docx;
            }
        }
        $this->send_zip($files, 'website-documents.zip');
    }

    private function send_file($data, $filename, $mime) {
        nocache_headers(); header('Content-Type: '.$mime); header('Content-Disposition: attachment; filename="'.$filename.'"');
        header('Content-Length: '.strlen($data)); echo $data; exit;
    }

    private function send_zip($files, $filename) {
        if (!class_exists('ZipArchive')) { wp_die(esc_html__('The PHP ZipArchive extension is required for batch ZIP downloads.', 'website-to-word-pdf'), 500); }
        $tmp = wp_tempnam('wtwp-batch.zip'); $zip = new ZipArchive();
        if (!$tmp || $zip->open($tmp, ZipArchive::OVERWRITE) !== true) { wp_die(esc_html__('Could not create batch archive.', 'website-to-word-pdf'), 500); }
        foreach ($files as $name=>$data) { if (is_wp_error($data)) { $zip->close(); @unlink($tmp); wp_die(esc_html($data->get_error_message()), 500); } $zip->addFromString($name, $data); }
        $zip->close(); $data = file_get_contents($tmp); @unlink($tmp); $this->send_file($data, $filename, 'application/zip');
    }
}
new WTWP_Plugin();
